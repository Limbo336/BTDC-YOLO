import warnings, os
# os.environ["CUDA_VISIBLE_DEVICES"]="-1"    # 代表用cpu训练 不推荐！没意义！ 而且有些模块不能在cpu上跑
# os.environ["CUDA_VISIBLE_DEVICES"]="0"     # 代表用第一张卡进行训练  0：第一张卡 1：第二张卡
# 多卡训练参考<YOLOV11配置文件.md>下方常见错误和解决方案
warnings.filterwarnings('ignore')
from ultralytics import YOLO
from torch import optim
from torch.optim import lr_scheduler

# 训练过程中loss出现nan，可以尝试关闭AMP，就是把下方amp=False的注释去掉。
# 训练时候输出的AMP Check使用的YOLO11n的权重不是代表载入了预训练权重的意思，只是用于测试AMP，正常的不需要理会。

# 使用项目前必看<项目视频百度云链接.txt>的第一行有一个必看的视频!!

if __name__ == '__main__':
    model = YOLO('ultralytics/cfg/models/BTDC-YOLO.yaml')
    #model = YOLO('ultralytics/cfg/models/gai2_brain/19/47.yaml')
    model.load('yolo11n.pt') # loading pretrain weights-WFU
    model.train(data='ultralytics/cfg/datasets/Br35H.yaml',
                cache=False,
                imgsz=640,
                epochs=250,
                batch=32,
                #  close_mosaic=0,
                workers=8, # Windows下出现莫名其妙卡主的情况可以尝试件.md>下方常见错误和解决方案
                optimizer='AdamW', # using SGD
                # patience=0, # set 0 to close earlystop.
                # resume=True, # 断点续训,YOLO初始化时选择last.pt
                # amp=False, # close amp | loss出现nan可以关闭amp
                # fraction=0.2,
                project='runs/train',
                name='exp',
                )
